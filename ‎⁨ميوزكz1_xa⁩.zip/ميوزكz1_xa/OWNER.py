# متطلبات التنصيب #

#يوزر المطور
OWNER = ["z1_xa"] 
OWNER__ID = 6094238403
OWNER_DEVELOPER = 6094238403
OWNER_NAME = "ᯤ‌𝐀𝐁𝐁𝐀𝐒𝐌𝐎𝐎𝟓𝟓ᯤ‌"
#اسم التي سيظهر على صورة
infophoto = "Alsayed Playing"
DATABASE = "mongodb+srv://huSeen96:Huseenslah96@cluster0.ld2v7.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0" 
#قناة سورس
CHANNEL = "https://t.me/z1_1ax"
#كروب سورس
GROUP = "https://t.me/z1_1ax"
#فيديو سورس اذا ماعندك خليه
VIDEO = "https://t.me/ABBBASDG/91"
#صورة سورس اذا ماعندك خليها
PHOTO = "https://t.me/ABBBASDG/15"
#ساوي كروب وضيف عليه مصنع ورفعو اشراف وحط يوزر الكروب هنا
LOGS = "ABBBASDG"
 
 